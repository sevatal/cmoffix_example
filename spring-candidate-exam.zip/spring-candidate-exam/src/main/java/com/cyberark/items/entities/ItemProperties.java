package com.cyberark.items.entities;

// Because we can't change the Item class the new class
// contains the new properties of Item was created.
// It can be a new table in the database with key 'Id'
// same to the Item table. And when we will want to received
// the values of the properties of item the join of the tables was executed.
public class ItemProperties {
    private long id;
    private int premium;

    public ItemProperties(long id, int premium) {
        this.id = id;
        this.setPremium(premium);
    }

    public ItemProperties() {
    }
    /* Generated getter and setter code */

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public int getPremium() {
        return premium;
    }

    public void setPremium(int premium) {
        this.premium = premium;
    }

    @Override
    public String toString() {
        return "ItemProperties{" +
                "id=" + id +
                ", premium=" + premium +
                '}';
    }
}
