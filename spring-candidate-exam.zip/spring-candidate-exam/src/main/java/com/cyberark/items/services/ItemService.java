package com.cyberark.items.services;

import com.cyberark.items.entities.Item;
import com.cyberark.items.entities.ItemProperties;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;


public interface ItemService {
    List<Item> getItems();
    Item getItem(long id);
    Item createItem(Item item);
    void updateQuality(List<Item> items);
    void updateQuality(List<Item> items, Map<Long, ItemProperties> itemProperties);
}
