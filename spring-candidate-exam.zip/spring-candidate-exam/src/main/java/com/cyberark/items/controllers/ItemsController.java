package com.cyberark.items.controllers;

import com.cyberark.items.entities.Item;
import com.cyberark.items.services.ItemService;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

import java.util.List;

import static org.springframework.http.HttpMethod.GET;

//import org.hibernate.validator.constraints.SafeHtml;

@RestController
//@RequestMapping("")
//@CrossOrigin
public class ItemsController {
    @Autowired
    private ItemService itemService;

    @PostMapping("api/items")
    public Item createItem(@RequestBody Item itemToCreate) throws JSONException {
        Item createdItem = itemService.createItem(itemToCreate);
        return itemToCreate;
    }

    @GetMapping("api/items")
    public List<Item> findAll(){
        List<Item> items = itemService.getItems();
        return items;
    }

    @GetMapping("api/items/{id}")
    public Item findById(@PathVariable("id")long id){
        return itemService.getItem(id);
    }

}
